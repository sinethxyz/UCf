# SKILL.md — extract-signals

## Description
Transforms raw startup signal sources into structured event and evidence JSON at scale using the batch processing lane.

## When to Use
- Raw source material needs normalization into Unicorn's event/evidence model.
- Task type is `extraction_batch`.
- Explicitly invoked via `/extract-signals`.

## Workflow

1. **Validate inputs.** Each source must have:
   - `source_id` (UUID)
   - `source_url` or `source_text` (at least one)
   - `source_type` (optional, will be classified if missing)
   - `company_hint` (optional, helps disambiguation)

2. **Load canon context.** Read:
   - `canon/docs/event_taxonomy.md`
   - `canon/docs/evidence_taxonomy.md`
   - `canon/schemas/event.schema.json`
   - `canon/schemas/evidence.schema.json`

3. **Build batch request.** For each source:
   - System prompt: canon taxonomy docs + schema + extraction instructions
   - User message: the raw source text + metadata
   - Output mode: structured JSON matching event schema
   - Enable prompt caching on the system prompt (shared across all items)

4. **Submit batch.** Call `POST /v1/batches/extract` which submits to Anthropic Message Batches API.

5. **Poll for completion.** Batch worker polls until all items resolve.

6. **Validate results.** For each completed item:
   - Parse the JSON output.
   - Validate against `event.schema.json` and `evidence.schema.json`.
   - If valid: store in `artifacts/extraction/{batch_id}/{item_id}.json`.
   - If invalid: flag in `batch_items` table with `is_valid = false` and the validation error.

7. **Push to unicorn-app.** For each valid extraction, call `POST /internal/ingest/source` on unicorn-app's internal API.

## Model Selection
- **Sonnet 4.6** for complex, ambiguous, or multi-event sources (funding announcements, long-form articles, founder interviews).
- **Haiku 4.5** for simple, single-event sources (changelog entries, app store updates, straightforward press releases).

Classification of source complexity can itself be a Haiku pre-pass.

## Output
Batch of validated extraction results stored as artifacts. Ingest calls to unicorn-app for valid items.

## Failure Conditions
- Source text is empty or gibberish → skip with error note.
- Schema validation fails → flag item, do not push to unicorn-app.
- Batch API timeout → retry once, then mark batch as failed.

## Cost Optimization
- Prompt caching: system prompt (canon docs + schemas + instructions) is identical across all items. Cache it.
- Batch API: 50% cost reduction vs. real-time.
- Haiku pre-classification: route simple sources to Haiku, saving Sonnet tokens for complex ones.

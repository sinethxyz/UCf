# SKILL.md — run-eval

## Description
Runs an evaluation suite against a dataset using a specified scorer, measuring extraction accuracy, evidence classification quality, or state inference correctness.

## When to Use
- After changing extraction prompts or canon schemas, to measure impact.
- On a schedule, to detect model drift.
- Task type is `eval_run`.
- Explicitly invoked via `/run-eval`.

## Workflow

1. **Load the dataset.** From `evals/datasets/{dataset_name}.jsonl`. Each line contains:
   - `input`: the raw source text or structured input
   - `expected`: the expected output (events, classifications, state)
   - `metadata`: optional context (source type, difficulty, etc.)

2. **Run inference.** For each item:
   - Build the prompt using the same system prompt and instructions as production.
   - Call the specified model via Messages API.
   - Collect the structured output.

3. **Score.** Load the scorer from `evals/scorers/{scorer_name}.py`. The scorer receives `(predicted, expected)` and returns per-item scores.

4. **Aggregate metrics.**
   - Per-field accuracy (for structured extraction)
   - Precision, recall, F1 (for classification tasks)
   - Exact match rate (for deterministic outputs)
   - Confidence calibration (predicted confidence vs. actual correctness)

5. **Store results.** Write to:
   - `eval_runs` table (aggregate metrics)
   - `artifacts/evals/{eval_id}/results.json` (full per-item breakdown)

6. **Compare to baseline.** If a previous eval exists for the same dataset + scorer:
   - Compute delta on all metrics.
   - Flag regressions (any metric dropping more than 2%).

## Available Datasets
- `extraction_accuracy` — tests event extraction from raw sources
- `evidence_strength` — tests evidence type and confidence classification
- `state_inference` — tests company state computation from event sequences

## Available Scorers
- `extraction_scorer` — field-level comparison of extracted events vs. expected
- `evidence_scorer` — evidence type and confidence accuracy
- `state_scorer` — state label and transition accuracy

## Output
Eval results artifact with aggregate metrics and per-item scores. Regression warnings if applicable.

## Constraints
- Evals use the same prompts as production. Do not use special eval-only prompts.
- Eval datasets are version-controlled. Changes to datasets require a PR.
- Never modify the scorer to make a failing eval pass. Fix the extraction logic instead.

# Migration Rules

## When Migrations Are Needed
A migration is required whenever:
- A new table is added
- A column is added, removed, or altered
- An index is added or removed
- A constraint is added, removed, or changed
- A view or materialized view is created or modified
- An enum type is added or altered

## Migration Safety

### Mandatory Checks
Every migration must be:
1. **Reversible** — include both `upgrade()` and `downgrade()` in Alembic.
2. **Non-destructive by default** — dropping columns or tables requires explicit justification in the plan artifact.
3. **Backwards-compatible** — the old code must be able to run against the new schema during rollout. This means:
   - Add new columns as nullable or with defaults.
   - Never rename columns in a single step (add new → migrate data → drop old).
   - Never drop columns that existing code reads from.

### Forbidden in a Single Migration
- Dropping a column that is still referenced by any query in the current codebase.
- Renaming a table.
- Changing a column type without a data migration step.
- Adding a NOT NULL column without a default to a table with existing rows.
- Any DDL + DML in the same transaction (Postgres handles this, but keep them logically separate).

## Migration Guard
The `migration-guard` subagent is automatically invoked for any run that touches files under `migrations/`. It uses Opus 4.6 and applies high-scrutiny review:

- Is the migration reversible?
- Is it backwards-compatible with the current codebase?
- Does it handle existing data correctly?
- Are there performance implications (large table locks, full table scans)?
- Is there a risk of data loss?

If migration guard rejects, the run transitions to `review_failed` and the PR is not opened.

## Migration Naming
Alembic auto-generates revision IDs. The migration message must be descriptive:

```
alembic revision --autogenerate -m "add company_relationships table"
alembic revision --autogenerate -m "add evidence_strength column to event_evidence"
```

## Task Authorization
Only `migration_plan` and `canon_update` task types are authorized to modify files under `migrations/`. All other task types are blocked by the `block_protected_paths` hook.
